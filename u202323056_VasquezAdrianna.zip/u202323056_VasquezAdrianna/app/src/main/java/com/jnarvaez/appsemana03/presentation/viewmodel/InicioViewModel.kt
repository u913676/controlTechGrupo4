package com.jnarvaez.appsemana03.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jnarvaez.appsemana03.domain.model.Libro
import com.jnarvaez.appsemana03.domain.usecase.LibroUseCases
import com.jnarvaez.appsemana03.presentation.event.EventBus
import com.jnarvaez.appsemana03.presentation.event.UiEvent
import com.jnarvaez.appsemana03.presentation.screens.inicio.InicioUiState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class InicioViewModel(private val useCases: LibroUseCases): ViewModel() {
    private val _uiState = MutableStateFlow(InicioUiState())
    val uiState = _uiState.asStateFlow()
    private var libros = listOf<Libro>()

    init {
        cargarLibros()
    }
    fun cargarLibros(){
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            try {
                libros = useCases.getLibros()
                _uiState.value = _uiState.value.copy(
                    listaLibros = libros,
                    isLoading = false,
                    search = "",
                    listaLibrosFiltro = emptyList())
            }catch (e: Exception){
                _uiState.value = _uiState.value.copy(isLoading = false, error = e.message)
                EventBus.send(UiEvent.Error("Error al listar libros: ${e.message}"))
            }

        }
    }

    fun setEliminar(estado: Boolean){
        _uiState.value = _uiState.value.copy(isDelete = estado)
    }

    fun eliminarLibro(id: String){
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            try {
                useCases.eliminarLibro(id)
                EventBus.send((UiEvent.Success("Libro eliminado")))
                _uiState.value = _uiState.value.copy(isLoading = false)
                cargarLibros()
            }catch (e: Exception){
                _uiState.value = _uiState.value.copy(isLoading = false, error = e.message)
                EventBus.send(UiEvent.Error("Error al eliminar libro: ${e.message}"))
            }
        }
    }

    fun onSearchChange(value: String) {
        _uiState.update {
            it.copy(search = value)
        }
        val filtered = libros.filter {
            "${it.titulo} ${it.autor}"
                .contains(value, true)
        }
        _uiState.update {
            it.copy(listaLibrosFiltro = filtered)
        }
    }
}