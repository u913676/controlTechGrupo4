package com.jnarvaez.appsemana03.data.repository

import com.jnarvaez.appsemana03.data.mapper.LibroMapper
import com.jnarvaez.appsemana03.data.remote.datasource.RemoteDataSource
import com.jnarvaez.appsemana03.domain.model.Libro
import com.jnarvaez.appsemana03.domain.repository.LibroRepository

class LibroRepositoryImpl(private val remoteDataSource: RemoteDataSource): LibroRepository {
    override suspend fun getLibros(): List<Libro> {
        return remoteDataSource.getLibros()?.data?.items?.map {
            LibroMapper.toDomain(it)
        }?:emptyList()
    }

    override suspend fun insertarLibro(libro: Libro) {
        remoteDataSource.insertarLibro(LibroMapper.toInsertLibroRequest(libro))
    }

    override suspend fun getLibroById(id: String): Libro {
        return remoteDataSource.getLibroById(id)?.let{ LibroMapper.toDomain(it) } ?: throw Exception("Libro no encontrado")
    }

    override suspend fun actualizarLibro(libro: Libro) {
        remoteDataSource.actualizarLibro(libro.id, LibroMapper.toInsertLibroRequest(libro))
    }

    override suspend fun eliminarLibro(id: String) {
        remoteDataSource.eliminarLibro(id)
    }
}