package com.jnarvaez.appsemana03.domain.usecase

import com.jnarvaez.appsemana03.domain.repository.AuthRepository

class LoginUseCase(private val repository: AuthRepository) {
    suspend operator fun invoke(correo: String, contrasena: String): Boolean =
        repository.login(correo, contrasena)
}
