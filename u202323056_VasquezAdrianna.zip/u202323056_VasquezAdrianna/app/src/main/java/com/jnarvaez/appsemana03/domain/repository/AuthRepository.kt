package com.jnarvaez.appsemana03.domain.repository

interface AuthRepository {
    suspend fun login(correo: String, contrasena: String): Boolean
}
