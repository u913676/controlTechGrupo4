package com.jnarvaez.appsemana03.di

import com.jnarvaez.appsemana03.domain.usecase.ActualizarLibroUseCase
import com.jnarvaez.appsemana03.domain.usecase.EliminarLibroUseCase
import com.jnarvaez.appsemana03.domain.usecase.GetEquiposUseCase
import com.jnarvaez.appsemana03.domain.usecase.GetLibroUseCase
import com.jnarvaez.appsemana03.domain.usecase.GetLibrosUseCase
import com.jnarvaez.appsemana03.domain.usecase.GetMovimientosRecientesUseCase
import com.jnarvaez.appsemana03.domain.usecase.InsertarLibroUseCase
import com.jnarvaez.appsemana03.domain.usecase.LibroUseCases
import com.jnarvaez.appsemana03.domain.usecase.LoginUseCase

class UseCaseModule(repositoryModule: RepositoryModule) {
    val libroUseCases by lazy {
        LibroUseCases(
            GetLibrosUseCase(repositoryModule.libroRepository),
            InsertarLibroUseCase(repositoryModule.libroRepository),
            GetLibroUseCase(repositoryModule.libroRepository),
            ActualizarLibroUseCase(repositoryModule.libroRepository),
            EliminarLibroUseCase(repositoryModule.libroRepository)
        )
    }

    val getEquiposUseCase by lazy {
        GetEquiposUseCase(repositoryModule.equipoRepository)
    }

    val getMovimientosRecientesUseCase by lazy {
        GetMovimientosRecientesUseCase(repositoryModule.movimientoRepository)
    }

    val loginUseCase by lazy {
        LoginUseCase(repositoryModule.authRepository)
    }
}