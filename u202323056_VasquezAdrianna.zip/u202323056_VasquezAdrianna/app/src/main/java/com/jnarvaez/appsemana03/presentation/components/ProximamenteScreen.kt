package com.jnarvaez.appsemana03.presentation.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Construction
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.jnarvaez.appsemana03.ui.theme.CtOnSurfaceVariant
import com.jnarvaez.appsemana03.ui.theme.CtOutline

@Composable
fun ProximamenteScreen(titulo: String) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Default.Construction,
            contentDescription = null,
            tint = CtOutline,
            modifier = Modifier.padding(bottom = 12.dp)
        )
        Text(
            text = titulo,
            style = MaterialTheme.typography.titleMedium
        )
        Text(
            text = "Esta sección estará disponible próximamente.",
            style = MaterialTheme.typography.bodyMedium,
            color = CtOnSurfaceVariant
        )
    }
}
