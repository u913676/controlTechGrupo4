package com.jnarvaez.appsemana03.domain.usecase

import com.jnarvaez.appsemana03.domain.model.Movimiento
import com.jnarvaez.appsemana03.domain.repository.MovimientoRepository

class GetMovimientosRecientesUseCase(private val repository: MovimientoRepository) {
    suspend operator fun invoke(): List<Movimiento> = repository.getMovimientosRecientes()
}
