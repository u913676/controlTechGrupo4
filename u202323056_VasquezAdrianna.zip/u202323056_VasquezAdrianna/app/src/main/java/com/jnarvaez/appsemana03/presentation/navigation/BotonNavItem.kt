package com.jnarvaez.appsemana03.presentation.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.ui.graphics.vector.ImageVector

sealed class BotonNavItem(val ruta: String, val titulo: String, val icono: ImageVector) {
    data object Panel : BotonNavItem(NavRutas.PANEL,"Inicio", Icons.Default.Home)
    data object Equipos : BotonNavItem(NavRutas.EQUIPOS,"Equipos", Icons.Default.Devices)
    data object Registrar : BotonNavItem(NavRutas.REGISTRAR,"Registrar", Icons.Default.AddCircle)
    data object Historial : BotonNavItem(NavRutas.HISTORIAL,"Historial", Icons.Default.History)
    data object Perfil : BotonNavItem(NavRutas.PERFIL,"Perfil", Icons.Default.Person)
}