package com.jnarvaez.appsemana03.domain.repository

import com.jnarvaez.appsemana03.domain.model.Libro

interface LibroRepository {
    suspend fun getLibros(): List<Libro>
    suspend fun insertarLibro(libro: Libro)
    suspend fun getLibroById(id: String): Libro
    suspend fun actualizarLibro(libro: Libro)
    suspend fun eliminarLibro(id: String)
}