package com.jnarvaez.appsemana03.presentation.screens.panel

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Laptop
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.PersonPin
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.Tablet
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.jnarvaez.appsemana03.di.AppContainer
import com.jnarvaez.appsemana03.domain.model.EstadoMovimiento
import com.jnarvaez.appsemana03.domain.model.Movimiento
import com.jnarvaez.appsemana03.presentation.components.LoadingScreen
import com.jnarvaez.appsemana03.presentation.navigation.NavRutas
import com.jnarvaez.appsemana03.ui.theme.CtEstadoAsignado
import com.jnarvaez.appsemana03.ui.theme.CtEstadoAsignadoBg
import com.jnarvaez.appsemana03.ui.theme.CtEstadoFueraServicio
import com.jnarvaez.appsemana03.ui.theme.CtEstadoFueraServicioBg
import com.jnarvaez.appsemana03.ui.theme.CtEstadoOperativo
import com.jnarvaez.appsemana03.ui.theme.CtEstadoOperativoBg
import com.jnarvaez.appsemana03.ui.theme.CtOnSurfaceVariant
import com.jnarvaez.appsemana03.ui.theme.CtOutline
import com.jnarvaez.appsemana03.ui.theme.CtOutlineVariant
import com.jnarvaez.appsemana03.ui.theme.CtPrimary
import com.jnarvaez.appsemana03.ui.theme.CtPrimaryContainer
import com.jnarvaez.appsemana03.ui.theme.CtSecondaryContainer
import com.jnarvaez.appsemana03.ui.theme.CtSurfaceContainer
import com.jnarvaez.appsemana03.ui.theme.CtSurfaceContainerLow

@Composable
fun PanelScreen(container: AppContainer, navHostController: NavHostController) {
    val viewModel = container.panelViewModel
    val uiState by viewModel.uiState.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CtSurfaceContainerLow)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { /* menú lateral: próximamente */ }) {
                    Icon(Icons.Default.Menu, contentDescription = "Menú", tint = CtPrimaryContainer)
                }
                Text(
                    text = "ControlTech",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = CtPrimaryContainer
                )
            }
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(CtSecondaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Text("T", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }

        if (uiState.isLoading) {
            LoadingScreen("Cargando panel...")
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp)
            ) {
                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "PANEL DE CONTROL",
                    style = MaterialTheme.typography.labelSmall,
                    color = CtOnSurfaceVariant
                )
                Text(
                    text = "Hola, ${uiState.nombreUsuario}",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = CtPrimary
                )

                Spacer(modifier = Modifier.height(16.dp))

                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    modifier = Modifier.height(260.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item(span = { GridItemSpan(2) }) {
                        TarjetaTotalEquipos(uiState.totalEquipos)
                    }
                    item {
                        TarjetaEstadistica(
                            titulo = "DISPONIBLES",
                            cantidad = uiState.disponibles,
                            icono = Icons.Default.CheckCircle,
                            color = CtEstadoOperativo
                        )
                    }
                    item {
                        TarjetaEstadistica(
                            titulo = "ASIGNADOS",
                            cantidad = uiState.asignados,
                            icono = Icons.Default.PersonPin,
                            color = CtEstadoAsignado
                        )
                    }
                    item {
                        TarjetaEstadistica(
                            titulo = "REPARACIÓN",
                            cantidad = uiState.enReparacion,
                            icono = Icons.Default.Build,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                    item {
                        TarjetaEstadistica(
                            titulo = "DE BAJA",
                            cantidad = uiState.deBaja,
                            icono = Icons.Default.Archive,
                            color = CtOutline
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = { navHostController.navigate(NavRutas.REGISTRAR) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp),
                    shape = RoundedCornerShape(50),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CtSecondaryContainer,
                        contentColor = Color.White
                    )
                ) {
                    Icon(Icons.Default.AddCircle, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Registrar nuevo equipo", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                }

                Spacer(modifier = Modifier.height(24.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Últimos movimientos",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    TextButton(onClick = { navHostController.navigate(NavRutas.HISTORIAL) }) {
                        Text("VER TODO", style = MaterialTheme.typography.labelSmall, color = CtSecondaryContainer)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = CtSurfaceContainer)
                ) {
                    Column {
                        uiState.movimientos.forEachIndexed { index, movimiento ->
                            MovimientoItem(movimiento)
                            if (index != uiState.movimientos.lastIndex) {
                                androidx.compose.material3.HorizontalDivider(color = CtOutlineVariant.copy(alpha = 0.4f))
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun TarjetaTotalEquipos(total: Int) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CtPrimaryContainer)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Bottom
        ) {
            Column {
                Text(
                    text = "Total Equipos",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White.copy(alpha = 0.8f)
                )
                Text(
                    text = total.toString(),
                    fontSize = 40.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color.White.copy(alpha = 0.15f))
                    .padding(8.dp)
            ) {
                Icon(Icons.Default.Inventory2, contentDescription = null, tint = Color.White)
            }
        }
    }
}

@Composable
private fun TarjetaEstadistica(titulo: String, cantidad: Int, icono: ImageVector, color: Color) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CtSurfaceContainer)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icono, contentDescription = null, tint = color, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(titulo, style = MaterialTheme.typography.labelSmall, color = color)
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = cantidad.toString(),
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
private fun MovimientoItem(movimiento: Movimiento) {
    val (colorTexto, colorFondo) = when (movimiento.estado) {
        EstadoMovimiento.ASIGNADO -> CtEstadoAsignado to CtEstadoAsignadoBg
        EstadoMovimiento.DANO -> CtEstadoFueraServicio to CtEstadoFueraServicioBg
        EstadoMovimiento.DISPONIBLE -> CtEstadoOperativo to CtEstadoOperativoBg
    }
    val icono = when {
        movimiento.tipoEquipo.contains("laptop", true) -> Icons.Default.Laptop
        movimiento.tipoEquipo.contains("red", true) -> Icons.Default.Router
        movimiento.tipoEquipo.contains("tablet", true) -> Icons.Default.Tablet
        else -> Icons.Default.Inventory2
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(colorFondo),
            contentAlignment = Alignment.Center
        ) {
            Icon(icono, contentDescription = null, tint = colorTexto)
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = movimiento.equipoNombre,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = movimiento.detalle,
                style = MaterialTheme.typography.labelSmall,
                color = CtOnSurfaceVariant
            )
        }
        Column(horizontalAlignment = Alignment.End) {
            Text(
                text = movimiento.hora,
                style = MaterialTheme.typography.labelSmall,
                color = CtOutline,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(4.dp))
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(colorFondo)
                    .padding(horizontal = 8.dp, vertical = 2.dp)
            ) {
                Text(
                    text = movimiento.estado.etiqueta.uppercase(),
                    style = MaterialTheme.typography.labelSmall,
                    fontSize = 9.sp,
                    color = colorTexto,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
