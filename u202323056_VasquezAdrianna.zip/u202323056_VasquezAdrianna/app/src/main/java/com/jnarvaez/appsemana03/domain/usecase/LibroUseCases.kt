package com.jnarvaez.appsemana03.domain.usecase

data class LibroUseCases(
    val getLibros: GetLibrosUseCase,
    val insertarLibro: InsertarLibroUseCase,
    val getLibro: GetLibroUseCase,
    val actualizarLibro: ActualizarLibroUseCase,
    val eliminarLibro : EliminarLibroUseCase
)
