package com.jnarvaez.appsemana03.data.remote.dto

data class ApiResponse(
    val success : Boolean,
    val data : LibrosDataDto,
    val timestamp : String
)
