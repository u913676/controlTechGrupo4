package com.jnarvaez.appsemana03.data.remote.dto

data class EquipoApiResponse(
    val success: Boolean,
    val data: EquiposDataDto,
    val timestamp: String
)
