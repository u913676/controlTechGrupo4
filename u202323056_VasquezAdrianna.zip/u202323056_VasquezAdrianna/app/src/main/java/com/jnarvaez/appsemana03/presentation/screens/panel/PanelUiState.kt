package com.jnarvaez.appsemana03.presentation.screens.panel

import com.jnarvaez.appsemana03.domain.model.Movimiento

data class PanelUiState(
    val isLoading: Boolean = false,
    val error: String? = null,
    val nombreUsuario: String = "Técnico",
    val totalEquipos: Int = 0,
    val disponibles: Int = 0,
    val asignados: Int = 0,
    val enReparacion: Int = 0,
    val deBaja: Int = 0,
    val movimientos: List<Movimiento> = emptyList()
)
