package com.jnarvaez.appsemana03.core.utils

object Constantes {
    const val BASE_URL = "https://31g6t5ue8c.execute-api.us-east-1.amazonaws.com/"
    const val EQUIPOS_BASE_URL = "https://53jx9lruy6.execute-api.us-east-1.amazonaws.com/"
}