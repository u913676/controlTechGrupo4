package com.jnarvaez.appsemana03.di

import com.jnarvaez.appsemana03.presentation.viewmodel.AgregarViewModel
import com.jnarvaez.appsemana03.presentation.viewmodel.EditarViewModel
import com.jnarvaez.appsemana03.presentation.viewmodel.EquiposViewModel
import com.jnarvaez.appsemana03.presentation.viewmodel.InicioViewModel
import com.jnarvaez.appsemana03.presentation.viewmodel.LoginViewModel
import com.jnarvaez.appsemana03.presentation.viewmodel.PanelViewModel

class AppContainer {
    private val networkModule by lazy { NetworkModule() }
    private val repositoryModule by lazy { RepositoryModule(networkModule) }
    private val useCaseModule by lazy { UseCaseModule(repositoryModule) }

    val inicioViewModel by lazy {
        InicioViewModel(useCaseModule.libroUseCases)
    }

    val agregarLibroViewModel by lazy {
        AgregarViewModel(useCaseModule.libroUseCases)
    }

    val editarLibroViewModel by lazy {
        EditarViewModel(useCaseModule.libroUseCases)
    }

    val loginViewModel by lazy {
        LoginViewModel(useCaseModule.loginUseCase)
    }

    val equiposViewModel by lazy {
        EquiposViewModel(useCaseModule.getEquiposUseCase)
    }

    val panelViewModel by lazy {
        PanelViewModel(useCaseModule.getEquiposUseCase, useCaseModule.getMovimientosRecientesUseCase)
    }
}