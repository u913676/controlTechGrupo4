package com.jnarvaez.appsemana03.di

import com.jnarvaez.appsemana03.data.local.datasource.MovimientoMockDataSource
import com.jnarvaez.appsemana03.data.remote.datasource.EquipoRemoteDataSource
import com.jnarvaez.appsemana03.data.remote.datasource.RemoteDataSource
import com.jnarvaez.appsemana03.data.repository.AuthRepositoryImpl
import com.jnarvaez.appsemana03.data.repository.EquipoRepositoryImpl
import com.jnarvaez.appsemana03.data.repository.LibroRepositoryImpl
import com.jnarvaez.appsemana03.data.repository.MovimientoRepositoryImpl
import com.jnarvaez.appsemana03.domain.repository.AuthRepository
import com.jnarvaez.appsemana03.domain.repository.EquipoRepository
import com.jnarvaez.appsemana03.domain.repository.LibroRepository
import com.jnarvaez.appsemana03.domain.repository.MovimientoRepository

class RepositoryModule(networkModule: NetworkModule) {
    private val remoteDataSource by lazy {
        RemoteDataSource(networkModule.apiService)
    }

    // Backend real de Equipos (API Gateway + Lambda + DynamoDB)
    private val equipoRemoteDataSource by lazy {
        EquipoRemoteDataSource(networkModule.equipoApiService)
    }

    // Aún no existe un endpoint de "movimientos" en el backend -> se mantiene mock.
    private val movimientoMockDataSource by lazy {
        MovimientoMockDataSource()
    }

    val libroRepository : LibroRepository by lazy {
        LibroRepositoryImpl(remoteDataSource)
    }

    val equipoRepository : EquipoRepository by lazy {
        EquipoRepositoryImpl(equipoRemoteDataSource)
    }

    val movimientoRepository : MovimientoRepository by lazy {
        MovimientoRepositoryImpl(movimientoMockDataSource)
    }

    val authRepository : AuthRepository by lazy {
        AuthRepositoryImpl()
    }
}
