package com.jnarvaez.appsemana03.domain.usecase

import com.jnarvaez.appsemana03.domain.model.Libro
import com.jnarvaez.appsemana03.domain.repository.LibroRepository

class GetLibroUseCase(private val repository: LibroRepository) {
    suspend operator fun invoke(id: String): Libro{
        return repository.getLibroById(id)
    }
}