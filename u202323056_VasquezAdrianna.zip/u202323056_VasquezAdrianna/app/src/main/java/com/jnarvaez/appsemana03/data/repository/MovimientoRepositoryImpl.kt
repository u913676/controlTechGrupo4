package com.jnarvaez.appsemana03.data.repository

import com.jnarvaez.appsemana03.data.local.datasource.MovimientoMockDataSource
import com.jnarvaez.appsemana03.domain.model.Movimiento
import com.jnarvaez.appsemana03.domain.repository.MovimientoRepository

class MovimientoRepositoryImpl(
    private val dataSource: MovimientoMockDataSource
) : MovimientoRepository {
    override suspend fun getMovimientosRecientes(): List<Movimiento> {
        return dataSource.getMovimientosRecientes()
    }
}
