package com.jnarvaez.appsemana03.domain.usecase

import com.jnarvaez.appsemana03.domain.repository.LibroRepository

class GetLibrosUseCase(private val repository: LibroRepository) {
    suspend operator fun invoke() = repository.getLibros()
}