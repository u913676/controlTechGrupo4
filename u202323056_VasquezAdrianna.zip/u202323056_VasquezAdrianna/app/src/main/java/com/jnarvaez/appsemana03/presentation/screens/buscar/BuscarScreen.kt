package com.jnarvaez.appsemana03.presentation.screens.buscar

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.SearchBar
import androidx.compose.material3.SearchBarDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.jnarvaez.appsemana03.di.AppContainer
import com.jnarvaez.appsemana03.presentation.components.EmptyScreen
import com.jnarvaez.appsemana03.presentation.components.LoadingScreen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BuscarScreen(container: AppContainer){
    val viewModel = container.inicioViewModel
    val uiState by viewModel.uiState.collectAsState()

    /*if(uiStateInicio.isLoading){
        LoadingScreen()
    }else{*/
        Column{
            SearchBar(
                inputField = {
                    SearchBarDefaults.InputField(
                        query = uiState.search,
                        onQueryChange = {
                            viewModel.onSearchChange(it)
                        },
                        onSearch = {},
                        expanded = false,
                        onExpandedChange = {},
                        placeholder = {
                            Text("Buscar libro")
                        }
                    )
                },
                expanded = false,
                onExpandedChange = {},
                modifier = Modifier.fillMaxWidth().padding(12.dp)
            ) {}

            if(uiState.listaLibrosFiltro.isEmpty()){
                EmptyScreen("No existen libros con el nombre buscado")
            }else {
                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    items(uiState.listaLibrosFiltro) { libro ->
                        LibroItemBuscar(
                            libro = libro
                        )
                    }
                }
            }
        }
    //}
}