package com.jnarvaez.appsemana03.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// ============ Paleta de marca ControlTech (tomada del prototipo Stitch) ============
val CtPrimary = Color(0xFF000666)
val CtPrimaryContainer = Color(0xFF1A237E)
val CtOnPrimaryContainer = Color(0xFF8690EE)
val CtSecondary = Color(0xFF006493)
val CtSecondaryContainer = Color(0xFF03A9F4)
val CtOnSecondaryContainer = Color(0xFF004162)
val CtTertiary = Color(0xFF000F5B)
val CtTertiaryContainer = Color(0xFF072189)

val CtBackground = Color(0xFFF9F9F9)
val CtOnBackground = Color(0xFF1A1C1C)
val CtSurface = Color(0xFFF9F9F9)
val CtSurfaceContainerLowest = Color(0xFFFFFFFF)
val CtSurfaceContainerLow = Color(0xFFF3F3F3)
val CtSurfaceContainer = Color(0xFFEEEEEE)
val CtSurfaceContainerHigh = Color(0xFFE8E8E8)
val CtSurfaceContainerHighest = Color(0xFFE2E2E2)
val CtOnSurface = Color(0xFF1A1C1C)
val CtOnSurfaceVariant = Color(0xFF454652)
val CtOutline = Color(0xFF767683)
val CtOutlineVariant = Color(0xFFC6C5D4)

val CtError = Color(0xFFBA1A1A)
val CtOnError = Color(0xFFFFFFFF)
val CtErrorContainer = Color(0xFFFFDAD6)
val CtOnErrorContainer = Color(0xFF93000A)

// Colores funcionales para estados de equipos
val CtEstadoOperativo = Color(0xFF2E7D32)      // Verde - En servicio
val CtEstadoOperativoBg = Color(0xFFE3F3E3)
val CtEstadoMantenimiento = Color(0xFFB98900)  // Ámbar - En mantenimiento
val CtEstadoMantenimientoBg = Color(0xFFFFF3D6)
val CtEstadoFueraServicio = Color(0xFFBA1A1A)  // Rojo - Fuera de servicio
val CtEstadoFueraServicioBg = Color(0xFFFFDAD6)
val CtEstadoAsignado = Color(0xFF006493)       // Azul - Asignado/Deployed
val CtEstadoAsignadoBg = Color(0xFFD6EEFF)