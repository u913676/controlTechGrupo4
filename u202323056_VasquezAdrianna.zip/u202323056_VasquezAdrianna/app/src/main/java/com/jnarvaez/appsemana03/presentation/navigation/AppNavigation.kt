package com.jnarvaez.appsemana03.presentation.navigation

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.jnarvaez.appsemana03.di.AppContainer
import com.jnarvaez.appsemana03.presentation.components.ProximamenteScreen
import com.jnarvaez.appsemana03.presentation.screens.agregar.AgregarScreen
import com.jnarvaez.appsemana03.presentation.screens.buscar.BuscarScreen
import com.jnarvaez.appsemana03.presentation.screens.editar.EditarScreen
import com.jnarvaez.appsemana03.presentation.screens.equipos.EquiposScreen
import com.jnarvaez.appsemana03.presentation.screens.inicio.InicioScreen
import com.jnarvaez.appsemana03.presentation.screens.login.LoginScreen
import com.jnarvaez.appsemana03.presentation.screens.panel.PanelScreen

@Composable
fun AppNavigation(navHostController: NavHostController, container: AppContainer, paddingValues: PaddingValues){
    NavHost(
        navController = navHostController,
        startDestination = NavRutas.LOGIN,
        modifier = Modifier.padding(paddingValues)
    ){
        composable(NavRutas.LOGIN){
            LoginScreen(container, navHostController)
        }
        composable(NavRutas.PANEL){
            PanelScreen(container, navHostController)
        }
        composable(NavRutas.EQUIPOS){
            ProximamenteScreen("Equipos")
        }
        composable(NavRutas.REGISTRAR){
            ProximamenteScreen("Registrar equipo")
        }
        composable(NavRutas.HISTORIAL){
            ProximamenteScreen("Historial de movimientos")
        }
        composable(NavRutas.PERFIL){
            ProximamenteScreen("Perfil")
        }
        composable(NavRutas.INICIO){
            InicioScreen(container, navHostController)
        }
        composable(NavRutas.AGREGAR){
            AgregarScreen(container, navHostController)
        }
        composable(NavRutas.BUSCAR){
            BuscarScreen(container)
        }
        composable("${NavRutas.EDITAR}/{id}"){entrada->
            val id = entrada.arguments?.getString("id")?:""
            EditarScreen(container,navHostController,id)
        }
    }
}