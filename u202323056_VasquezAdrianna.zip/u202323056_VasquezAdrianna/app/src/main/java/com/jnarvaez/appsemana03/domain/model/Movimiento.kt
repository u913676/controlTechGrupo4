package com.jnarvaez.appsemana03.domain.model

enum class EstadoMovimiento(val etiqueta: String) {
    ASIGNADO("Asignado"),
    DANO("Daño"),
    DISPONIBLE("Disponible")
}

data class Movimiento(
    val id: String,
    val equipoNombre: String,
    val tipoEquipo: String,
    val detalle: String,
    val hora: String,
    val estado: EstadoMovimiento
)
