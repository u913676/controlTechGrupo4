package com.jnarvaez.appsemana03.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jnarvaez.appsemana03.domain.model.EstadoEquipo
import com.jnarvaez.appsemana03.domain.usecase.GetEquiposUseCase
import com.jnarvaez.appsemana03.domain.usecase.GetMovimientosRecientesUseCase
import com.jnarvaez.appsemana03.presentation.event.EventBus
import com.jnarvaez.appsemana03.presentation.event.UiEvent
import com.jnarvaez.appsemana03.presentation.screens.panel.PanelUiState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class PanelViewModel(
    private val getEquiposUseCase: GetEquiposUseCase,
    private val getMovimientosRecientesUseCase: GetMovimientosRecientesUseCase
) : ViewModel() {
    private val _uiState = MutableStateFlow(PanelUiState())
    val uiState = _uiState.asStateFlow()

    init {
        cargarPanel()
    }

    fun cargarPanel() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            try {
                val equipos = getEquiposUseCase()
                val movimientos = getMovimientosRecientesUseCase()
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        totalEquipos = equipos.size,
                        disponibles = equipos.count { e -> e.estado == EstadoEquipo.OPERATIVO },
                        asignados = equipos.count { e -> e.estado == EstadoEquipo.ASIGNADO },
                        enReparacion = equipos.count { e -> e.estado == EstadoEquipo.MANTENIMIENTO },
                        deBaja = equipos.count { e -> e.estado == EstadoEquipo.FUERA_SERVICIO },
                        movimientos = movimientos
                    )
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(isLoading = false, error = e.message) }
                EventBus.send(UiEvent.Error("Error al cargar el panel: ${e.message}"))
            }
        }
    }
}
