package com.jnarvaez.appsemana03.presentation.screens.inicio

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import com.jnarvaez.appsemana03.di.AppContainer
import com.jnarvaez.appsemana03.domain.model.Libro
import com.jnarvaez.appsemana03.presentation.components.ConfirmarDialog
import com.jnarvaez.appsemana03.presentation.components.EmptyScreen
import com.jnarvaez.appsemana03.presentation.components.LoadingScreen
import com.jnarvaez.appsemana03.presentation.navigation.NavRutas
import com.jnarvaez.appsemana03.presentation.screens.equipos.EquipoItem

@Composable
fun InicioScreen(container: AppContainer, navHostController: NavHostController) {
    val viewModel = container.equiposViewModel
    val uiState by viewModel.uiState.collectAsState()

    if (uiState.isLoading) {
        LoadingScreen("Cargando equipos...")
    } else {
        if (uiState.listaEquipos.isEmpty()) {
            EmptyScreen("No existen equipos registrados")
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(uiState.listaEquipos) { equipo ->
                    EquipoItem(equipo = equipo)
                }
            }
        }
    }
}