package com.jnarvaez.appsemana03.presentation.screens.login

data class LoginUiState(
    val correo: String = "",
    val contrasena: String = "",
    val recordarme: Boolean = false,
    val mostrarContrasena: Boolean = false,
    val isLoading: Boolean = false,
    val errorCorreo: String? = null,
    val errorContrasena: String? = null,
    val loginExitoso: Boolean = false
)
