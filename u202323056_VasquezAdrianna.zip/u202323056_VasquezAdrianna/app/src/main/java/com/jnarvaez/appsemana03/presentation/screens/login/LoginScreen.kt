package com.jnarvaez.appsemana03.presentation.screens.login

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.jnarvaez.appsemana03.R
import com.jnarvaez.appsemana03.di.AppContainer
import com.jnarvaez.appsemana03.presentation.navigation.NavRutas
import com.jnarvaez.appsemana03.ui.theme.CtOnSurfaceVariant
import com.jnarvaez.appsemana03.ui.theme.CtOutline
import com.jnarvaez.appsemana03.ui.theme.CtOutlineVariant
import com.jnarvaez.appsemana03.ui.theme.CtPrimary
import com.jnarvaez.appsemana03.ui.theme.CtPrimaryContainer
import com.jnarvaez.appsemana03.ui.theme.CtSecondaryContainer
import com.jnarvaez.appsemana03.ui.theme.CtSurfaceContainer
import com.jnarvaez.appsemana03.ui.theme.CtSurfaceContainerLow
import com.jnarvaez.appsemana03.ui.theme.CtSurfaceContainerLowest

@Composable
fun LoginScreen(container: AppContainer, navHostController: NavHostController) {
    val viewModel = container.loginViewModel
    val uiState by viewModel.uiState.collectAsState()

    LaunchedEffect(uiState.loginExitoso) {
        if (uiState.loginExitoso) {
            navHostController.navigate(NavRutas.PANEL) {
                popUpTo(NavRutas.LOGIN) { inclusive = true }
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CtSurfaceContainerLow)
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = CtSurfaceContainerLowest),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier.padding(28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color.White),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.ic_controltech_logo),
                            contentDescription = "Logo ControlTech",
                            modifier = Modifier
                                .size(52.dp)
                                .padding(4.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "ControlTech",
                        fontSize = 26.sp,
                        fontWeight = FontWeight.Bold,
                        color = CtPrimary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Gestión inteligente de activos tecnológicos",
                        style = MaterialTheme.typography.bodyMedium,
                        color = CtOnSurfaceVariant,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(28.dp))

                    CampoLogin(
                        etiqueta = "CORREO ELECTRÓNICO",
                        valor = uiState.correo,
                        placeholder = "ejemplo@controltech.com",
                        icono = Icons.Default.Email,
                        error = uiState.errorCorreo,
                        keyboardType = KeyboardType.Email,
                        onValueChange = viewModel::onCorreoChange
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    CampoLogin(
                        etiqueta = "CONTRASEÑA",
                        valor = uiState.contrasena,
                        placeholder = "••••••••",
                        icono = Icons.Default.Lock,
                        error = uiState.errorContrasena,
                        keyboardType = KeyboardType.Password,
                        esContrasena = true,
                        mostrarContrasena = uiState.mostrarContrasena,
                        onToggleMostrar = viewModel::toggleMostrarContrasena,
                        onValueChange = viewModel::onContrasenaChange
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(
                                checked = uiState.recordarme,
                                onCheckedChange = viewModel::onRecordarmeChange,
                                colors = CheckboxDefaults.colors(checkedColor = CtSecondaryContainer)
                            )
                            Text(
                                text = "Recordarme",
                                style = MaterialTheme.typography.bodySmall,
                                color = CtOnSurfaceVariant
                            )
                        }
                        Text(
                            text = "¿Olvidó su contraseña?",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            color = CtSecondaryContainer
                        )
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    Button(
                        onClick = { viewModel.iniciarSesion() },
                        enabled = !uiState.isLoading,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp),
                        shape = RoundedCornerShape(50),
                        colors = ButtonDefaults.buttonColors(containerColor = CtPrimaryContainer)
                    ) {
                        if (uiState.isLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(22.dp),
                                color = Color.White,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text("Validando...", fontWeight = FontWeight.SemiBold)
                        } else {
                            Text("Iniciar sesión", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Text(
                        text = "¿Nuevo en la plataforma? Solicitar acceso",
                        style = MaterialTheme.typography.bodySmall,
                        color = CtOnSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = CtSecondaryContainer,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "SISTEMAS OPERATIVOS",
                    style = MaterialTheme.typography.labelSmall,
                    color = CtOutline
                )
            }
        }
    }
}

@Composable
private fun CampoLogin(
    etiqueta: String,
    valor: String,
    placeholder: String,
    icono: androidx.compose.ui.graphics.vector.ImageVector,
    error: String?,
    keyboardType: KeyboardType,
    onValueChange: (String) -> Unit,
    esContrasena: Boolean = false,
    mostrarContrasena: Boolean = false,
    onToggleMostrar: (() -> Unit)? = null
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = etiqueta,
            style = MaterialTheme.typography.labelSmall,
            color = CtOutline
        )
        Spacer(modifier = Modifier.height(4.dp))
        TextField(
            value = valor,
            onValueChange = onValueChange,
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text(placeholder, color = CtOutlineVariant) },
            singleLine = true,
            leadingIcon = { Icon(icono, contentDescription = null, tint = CtOutline) },
            trailingIcon = {
                if (esContrasena && onToggleMostrar != null) {
                    IconButton(onClick = onToggleMostrar) {
                        Icon(
                            imageVector = if (mostrarContrasena) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                            contentDescription = "Mostrar contraseña",
                            tint = CtOutline
                        )
                    }
                }
            },
            visualTransformation = if (esContrasena && !mostrarContrasena) PasswordVisualTransformation() else VisualTransformation.None,
            keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
            isError = error != null,
            shape = RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = CtSurfaceContainer,
                unfocusedContainerColor = CtSurfaceContainer,
                disabledContainerColor = CtSurfaceContainer,
                focusedIndicatorColor = CtSecondaryContainer,
                unfocusedIndicatorColor = CtOutlineVariant,
                errorIndicatorColor = MaterialTheme.colorScheme.error
            )
        )
        if (error != null) {
            Text(
                text = error,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.padding(top = 4.dp, start = 4.dp)
            )
        }
    }
}
