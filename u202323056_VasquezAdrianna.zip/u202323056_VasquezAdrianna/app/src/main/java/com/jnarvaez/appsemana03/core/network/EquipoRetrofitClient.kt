package com.jnarvaez.appsemana03.core.network

import com.jnarvaez.appsemana03.core.utils.Constantes
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object EquipoRetrofitClient {
    val api : EquipoApiService by lazy {
        Retrofit.Builder()
            .baseUrl(Constantes.EQUIPOS_BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build().create(EquipoApiService::class.java)
    }
}
