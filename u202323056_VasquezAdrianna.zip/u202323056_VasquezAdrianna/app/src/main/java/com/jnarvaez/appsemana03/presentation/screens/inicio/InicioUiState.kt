package com.jnarvaez.appsemana03.presentation.screens.inicio

import com.jnarvaez.appsemana03.domain.model.Libro

data class InicioUiState(
    val listaLibros : List<Libro> = emptyList(),
    val isLoading : Boolean = false,
    val error : String? = null,
    val isDelete : Boolean = false,
    val search: String = "",
    val listaLibrosFiltro : List<Libro> = emptyList()
)
