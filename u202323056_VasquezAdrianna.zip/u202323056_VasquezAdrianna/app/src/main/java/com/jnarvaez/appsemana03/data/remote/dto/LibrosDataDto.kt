package com.jnarvaez.appsemana03.data.remote.dto

data class LibrosDataDto(
    val items : List<LibroDto>,
    val nextKey : String?
)
