package com.jnarvaez.appsemana03.presentation.screens.equipos

import com.jnarvaez.appsemana03.domain.model.Equipo
import com.jnarvaez.appsemana03.domain.model.EstadoEquipo

data class EquiposUiState(
    val listaEquipos: List<Equipo> = emptyList(),
    val isLoading: Boolean = false,
    val error: String? = null,
    val filtroEstado: EstadoEquipo? = null,
    val busqueda: String = ""
) {
    val equiposFiltrados: List<Equipo>
        get() = listaEquipos
            .filter { filtroEstado == null || it.estado == filtroEstado }
            .filter {
                busqueda.isBlank() ||
                    "${it.nombre} ${it.tipo} ${it.numeroSerie} ${it.ubicacion}"
                        .contains(busqueda, ignoreCase = true)
            }

    val totalOperativos: Int get() = listaEquipos.count { it.estado == EstadoEquipo.OPERATIVO }
    val totalMantenimiento: Int get() = listaEquipos.count { it.estado == EstadoEquipo.MANTENIMIENTO }
    val totalFueraServicio: Int get() = listaEquipos.count { it.estado == EstadoEquipo.FUERA_SERVICIO }
}
