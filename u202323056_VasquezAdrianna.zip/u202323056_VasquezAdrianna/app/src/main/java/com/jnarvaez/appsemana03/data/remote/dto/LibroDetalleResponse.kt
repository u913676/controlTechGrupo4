package com.jnarvaez.appsemana03.data.remote.dto

data class LibroDetalleResponse(
    val success : Boolean,
    val data : LibroDto,
    val timestamp : String
)
