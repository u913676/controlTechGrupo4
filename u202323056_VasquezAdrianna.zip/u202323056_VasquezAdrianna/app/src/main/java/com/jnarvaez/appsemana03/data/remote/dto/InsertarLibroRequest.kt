package com.jnarvaez.appsemana03.data.remote.dto

data class InsertarLibroRequest(
    val titulo : String,
    val autor : String,
    val anio : Int,
    val genero : String,
    val descripcion : String
)
