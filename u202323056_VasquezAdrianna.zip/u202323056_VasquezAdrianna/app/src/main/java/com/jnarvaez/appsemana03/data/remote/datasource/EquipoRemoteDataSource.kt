package com.jnarvaez.appsemana03.data.remote.datasource

import com.jnarvaez.appsemana03.core.network.EquipoApiService
import com.jnarvaez.appsemana03.data.remote.dto.EquipoApiResponse
import com.jnarvaez.appsemana03.data.remote.dto.EquipoDto
import com.jnarvaez.appsemana03.data.remote.dto.InsertarEquipoRequest

class EquipoRemoteDataSource(private val api: EquipoApiService) {
    suspend fun getEquipos(limit: Int? = null): EquipoApiResponse? {
        return api.getEquipos(limit).body()
    }

    suspend fun insertarEquipo(request: InsertarEquipoRequest): EquipoDto? {
        return api.insertarEquipo(request).body()?.data
    }

    suspend fun getEquipoById(id: String): EquipoDto? {
        return api.getEquipoById(id).body()?.data
    }

    suspend fun actualizarEquipo(id: String, request: InsertarEquipoRequest): EquipoDto? {
        return api.actualizarEquipo(id, request).body()?.data
    }

    suspend fun eliminarEquipo(id: String) {
        api.eliminarEquipo(id)
    }
}
