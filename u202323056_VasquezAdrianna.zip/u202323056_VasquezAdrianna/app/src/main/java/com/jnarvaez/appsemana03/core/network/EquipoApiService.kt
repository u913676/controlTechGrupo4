package com.jnarvaez.appsemana03.core.network

import com.jnarvaez.appsemana03.data.remote.dto.EquipoApiResponse
import com.jnarvaez.appsemana03.data.remote.dto.EquipoDetalleResponse
import com.jnarvaez.appsemana03.data.remote.dto.InsertarEquipoRequest
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Path
import retrofit2.http.Query

interface EquipoApiService {
    @GET("equipos")
    suspend fun getEquipos(@Query("limit") limit: Int? = null): Response<EquipoApiResponse>

    @POST("equipos")
    suspend fun insertarEquipo(@Body request: InsertarEquipoRequest): Response<EquipoDetalleResponse>

    @GET("equipos/{id}")
    suspend fun getEquipoById(@Path("id") id: String): Response<EquipoDetalleResponse>

    @PUT("equipos/{id}")
    suspend fun actualizarEquipo(@Path("id") id: String, @Body request: InsertarEquipoRequest): Response<EquipoDetalleResponse>

    @DELETE("equipos/{id}")
    suspend fun eliminarEquipo(@Path("id") id: String): Response<Unit>
}
