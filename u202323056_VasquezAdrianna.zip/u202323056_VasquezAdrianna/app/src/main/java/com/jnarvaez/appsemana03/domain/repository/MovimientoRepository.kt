package com.jnarvaez.appsemana03.domain.repository

import com.jnarvaez.appsemana03.domain.model.Movimiento

interface MovimientoRepository {
    suspend fun getMovimientosRecientes(): List<Movimiento>
}
