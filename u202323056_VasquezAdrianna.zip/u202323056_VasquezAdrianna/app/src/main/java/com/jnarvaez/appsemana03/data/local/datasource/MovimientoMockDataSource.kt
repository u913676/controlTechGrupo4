package com.jnarvaez.appsemana03.data.local.datasource

import com.jnarvaez.appsemana03.domain.model.Movimiento
import kotlinx.coroutines.delay
class MovimientoMockDataSource {
    suspend fun getMovimientosRecientes(): List<Movimiento> {
        delay(400)
        return emptyList()
    }
}
