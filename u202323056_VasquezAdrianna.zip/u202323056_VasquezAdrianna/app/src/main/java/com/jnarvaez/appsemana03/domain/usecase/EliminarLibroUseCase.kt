package com.jnarvaez.appsemana03.domain.usecase

import com.jnarvaez.appsemana03.domain.repository.LibroRepository

class EliminarLibroUseCase(private val repository: LibroRepository) {
    suspend operator fun invoke(id: String){
        repository.eliminarLibro(id)
    }
}