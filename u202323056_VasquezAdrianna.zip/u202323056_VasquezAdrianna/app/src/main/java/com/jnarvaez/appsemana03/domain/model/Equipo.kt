package com.jnarvaez.appsemana03.domain.model

enum class EstadoEquipo(val etiqueta: String) {
    OPERATIVO("Disponible"),
    MANTENIMIENTO("En reparación"),
    FUERA_SERVICIO("De baja"),
    ASIGNADO("Asignado")
}

data class Equipo(
    val id: String,
    val nombre: String,
    val tipo: String,
    val numeroSerie: String,
    val ubicacion: String,
    val responsable: String,
    val estado: EstadoEquipo,
    val ultimaActualizacion: String
)
