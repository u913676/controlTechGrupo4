package com.jnarvaez.appsemana03.data.repository

import com.jnarvaez.appsemana03.domain.repository.AuthRepository
import kotlinx.coroutines.delay

/**
 * Autenticación de prueba (mock) mientras no exista un endpoint real.
 *
 * Cuando exista el backend, esta clase pasa a llamar a un ApiService/
 * RemoteDataSource igual que LibroRepositoryImpl (ver esa clase como
 * referencia), sin necesidad de tocar el resto de capas.
 *
 * Credenciales de prueba: admin@controltech.com / 123456
 */
class AuthRepositoryImpl : AuthRepository {
    override suspend fun login(correo: String, contrasena: String): Boolean {
        delay(1200) // Simula la validación contra un servidor
        return correo.equals("admin@controltech.com", ignoreCase = true) && contrasena == "123456"
    }
}
