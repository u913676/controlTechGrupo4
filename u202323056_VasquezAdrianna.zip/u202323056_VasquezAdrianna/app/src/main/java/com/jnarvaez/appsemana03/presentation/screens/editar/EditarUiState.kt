package com.jnarvaez.appsemana03.presentation.screens.editar

data class EditarUiState(
    val id: String = "",
    val titulo: String = "",
    val autor: String = "",
    val anio: String = "",
    val genero: String = "",
    val descripcion: String = "",
    val isLoading: Boolean = false,
    val isSuccess: Boolean = false,
    val errorMessage: String? = null
)
