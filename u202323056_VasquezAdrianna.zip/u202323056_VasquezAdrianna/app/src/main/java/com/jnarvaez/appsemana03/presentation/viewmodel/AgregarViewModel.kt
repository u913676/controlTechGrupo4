package com.jnarvaez.appsemana03.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jnarvaez.appsemana03.domain.model.Libro
import com.jnarvaez.appsemana03.domain.usecase.LibroUseCases
import com.jnarvaez.appsemana03.presentation.event.EventBus
import com.jnarvaez.appsemana03.presentation.event.UiEvent
import com.jnarvaez.appsemana03.presentation.screens.agregar.AgregarUiState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class AgregarViewModel(private val useCases: LibroUseCases) : ViewModel() {
    private val _uiState = MutableStateFlow(AgregarUiState())
    val uiState = _uiState.asStateFlow()

    fun onTituloChange(valor: String){
        _uiState.value = _uiState.value.copy(titulo = valor)
    }

    fun onAutorChange(valor: String){
        _uiState.value = _uiState.value.copy(autor = valor)
    }

    fun onAnioChange(valor: String){
        _uiState.value = _uiState.value.copy(anio = valor)
    }

    fun onGeneroChange(valor: String){
        _uiState.value = _uiState.value.copy(genero = valor)
    }

    fun onDescripcionChange(valor: String){
        _uiState.value = _uiState.value.copy(descripcion = valor)
    }

    fun guardarLibro(){
        viewModelScope.launch {
            if(!validarFormulario()){
                return@launch
            }
            try {
                _uiState.value = _uiState.value.copy(isLoading = true)
                val libro = Libro("",_uiState.value.titulo,_uiState.value.autor,
                    _uiState.value.anio.toInt(),_uiState.value.genero,_uiState.value.descripcion)
                useCases.insertarLibro(libro)
                limpiarForm()
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    isSuccess = true
                )
                EventBus.send(UiEvent.Success("Libro registrado correctamente"))
            }catch (e: Exception){
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    errorMessage = e.message
                )
            }
        }
    }

    private fun limpiarForm(){
        _uiState.value = _uiState.value.copy(titulo = "", autor = "", anio = "", genero = "", descripcion = "")
    }

    fun clearSuccess(){
        _uiState.value = _uiState.value.copy(isSuccess = false)
    }

    private suspend fun validarFormulario(): Boolean{
        when{
            _uiState.value.titulo.isBlank() -> {
                EventBus.send(UiEvent.Warning("Ingrese el título"))
                return false
            }

            _uiState.value.autor.isBlank() -> {
                EventBus.send(UiEvent.Warning("Ingrese el autor"))
                return false
            }

            _uiState.value.anio.isBlank() -> {
                EventBus.send(UiEvent.Warning("Ingrese el año"))
                return false
            }

            _uiState.value.genero.isBlank() -> {
                EventBus.send(UiEvent.Warning("Ingrese el género"))
                return false
            }

            _uiState.value.descripcion.isBlank() -> {
                EventBus.send(UiEvent.Warning("Ingrese la descripción"))
                return false
            }
        }
        return true
    }
}