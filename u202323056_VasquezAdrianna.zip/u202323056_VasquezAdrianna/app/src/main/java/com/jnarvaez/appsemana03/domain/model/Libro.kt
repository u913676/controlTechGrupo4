package com.jnarvaez.appsemana03.domain.model

data class Libro(
    val id: String,
    val titulo : String,
    val autor : String,
    val anio : Int,
    val genero : String,
    val descripcion : String
)
