package com.jnarvaez.appsemana03.core.network

import com.jnarvaez.appsemana03.data.remote.dto.ApiResponse
import com.jnarvaez.appsemana03.data.remote.dto.InsertarLibroRequest
import com.jnarvaez.appsemana03.data.remote.dto.LibroDetalleResponse
import com.jnarvaez.appsemana03.data.remote.dto.LibroDto
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Path

interface ApiService {
    @GET("libros")
    suspend fun getLibros(): Response<ApiResponse>

    @POST("libros")
    suspend fun insertarLibro(@Body request: InsertarLibroRequest): Response<LibroDto>

    @GET("libros/{id}")
    suspend fun getLibroById(@Path("id") id: String): Response<LibroDetalleResponse>

    @PUT("libros/{id}")
    suspend fun actualizarLibro(@Path("id") id: String, @Body request: InsertarLibroRequest): Response<LibroDto>

    @DELETE("libros/{id}")
    suspend fun eliminarLibro(@Path("id") id: String): Response<Unit>
}