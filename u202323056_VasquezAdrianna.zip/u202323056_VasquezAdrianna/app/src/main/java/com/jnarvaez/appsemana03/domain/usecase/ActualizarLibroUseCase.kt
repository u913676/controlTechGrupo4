package com.jnarvaez.appsemana03.domain.usecase

import com.jnarvaez.appsemana03.domain.model.Libro
import com.jnarvaez.appsemana03.domain.repository.LibroRepository

class ActualizarLibroUseCase(private val repository: LibroRepository) {
    suspend operator fun invoke(libro: Libro){
        repository.actualizarLibro(libro)
    }
}