package com.jnarvaez.appsemana03.data.mapper

import com.jnarvaez.appsemana03.data.remote.dto.EquipoDto
import com.jnarvaez.appsemana03.data.remote.dto.InsertarEquipoRequest
import com.jnarvaez.appsemana03.domain.model.Equipo
import com.jnarvaez.appsemana03.domain.model.EstadoEquipo

object EquipoMapper {
    fun toDomain(dto: EquipoDto): Equipo = Equipo(
        id = dto.id,
        nombre = dto.nombre,
        tipo = dto.tipo,
        numeroSerie = dto.numeroSerie,
        ubicacion = dto.ubicacion,
        responsable = dto.responsable,
        estado = runCatching { EstadoEquipo.valueOf(dto.estado) }.getOrDefault(EstadoEquipo.OPERATIVO),
        ultimaActualizacion = dto.ultimaActualizacion ?: "-"
    )

    fun toInsertRequest(equipo: Equipo): InsertarEquipoRequest = InsertarEquipoRequest(
        nombre = equipo.nombre,
        tipo = equipo.tipo,
        numeroSerie = equipo.numeroSerie,
        ubicacion = equipo.ubicacion,
        responsable = equipo.responsable,
        estado = equipo.estado.name
    )
}
