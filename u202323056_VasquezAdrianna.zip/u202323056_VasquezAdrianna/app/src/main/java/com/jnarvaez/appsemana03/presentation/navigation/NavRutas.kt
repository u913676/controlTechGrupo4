package com.jnarvaez.appsemana03.presentation.navigation

object NavRutas {
    const val LOGIN = "login"
    const val PANEL = "panel"
    const val EQUIPOS = "equipos"
    const val REGISTRAR = "registrar"
    const val HISTORIAL = "historial"
    const val PERFIL = "perfil"
    const val INICIO = "inicio"
    const val AGREGAR = "agregar"
    const val EDITAR = "editar"
    const val BUSCAR = "buscar"

    fun getTitulo(ruta: String?): String{
        return when{
            ruta == LOGIN -> "ControlTech"
            ruta == PANEL -> "Panel de Control"
            ruta == EQUIPOS -> "Equipos"
            ruta == REGISTRAR -> "Registrar equipo"
            ruta == HISTORIAL -> "Historial"
            ruta == PERFIL -> "Perfil"
            ruta == INICIO -> "APP Biblioteca"
            ruta == AGREGAR -> "Nuevo Libro"
            ruta?.startsWith(EDITAR) == true -> "Editar Libro"
            ruta?.startsWith(BUSCAR) == true -> "Buscar Libro"
            else -> "ControlTech"
        }
    }
}