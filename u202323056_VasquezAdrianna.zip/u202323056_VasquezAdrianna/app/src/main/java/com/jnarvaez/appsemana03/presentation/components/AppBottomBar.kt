package com.jnarvaez.appsemana03.presentation.components

import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.navigation.NavHostController
import androidx.navigation.compose.currentBackStackEntryAsState
import com.jnarvaez.appsemana03.presentation.navigation.BotonNavItem

@Composable
fun AppBottomBar(navHostController: NavHostController){
    val opciones = listOf(
        BotonNavItem.Panel,
        BotonNavItem.Equipos,
        BotonNavItem.Registrar,
        BotonNavItem.Historial,
        BotonNavItem.Perfil
    )

    NavigationBar(
        containerColor = Color(0xFF1A237E)
    ){
        val rutaSel = navHostController.currentBackStackEntryAsState().value?.destination?.route
        opciones.forEach { item ->
            NavigationBarItem(
                selected = rutaSel == item.ruta,
                onClick = { navHostController.navigate(item.ruta) },
                icon = { Icon(item.icono,"") },
                label = { Text(item.titulo) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Color(0xFFFFFFFF),
                    indicatorColor = Color(0xFF03A9F4),
                    selectedTextColor = Color(0xFFFFFFFF),
                    unselectedIconColor = Color(0xFFBDC2FF),
                    unselectedTextColor = Color(0xFFBDC2FF)
                )
            )
        }
    }
}