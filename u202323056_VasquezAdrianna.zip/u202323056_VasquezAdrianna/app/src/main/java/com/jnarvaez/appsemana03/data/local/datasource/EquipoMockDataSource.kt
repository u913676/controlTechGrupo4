package com.jnarvaez.appsemana03.data.local.datasource

import com.jnarvaez.appsemana03.domain.model.Equipo
import com.jnarvaez.appsemana03.domain.model.EstadoEquipo
import kotlinx.coroutines.delay

/**
 * Fuente de datos de prueba (mock) para el módulo de Equipos.
 *
 * Cuando exista un endpoint real en el backend (por ejemplo "equipos"),
 * basta con crear un RemoteDataSource + ApiService análogos a los de
 * Libro (ver data/remote/datasource/RemoteDataSource.kt) e inyectarlos
 * en EquipoRepositoryImpl en lugar de esta clase.
 */
class EquipoMockDataSource {
    private val equipos = listOf(
        Equipo(
            id = "1",
            nombre = "Laptop Dell Latitude 5440",
            tipo = "Laptop",
            numeroSerie = "DL-5440-8841",
            ubicacion = "Piso 3 - Desarrollo",
            responsable = "María Fernández",
            estado = EstadoEquipo.OPERATIVO,
            ultimaActualizacion = "Hoy, 08:12 a.m."
        ),
        Equipo(
            id = "2",
            nombre = "Servidor HP ProLiant DL380",
            tipo = "Servidor",
            numeroSerie = "HP-DL380-2201",
            ubicacion = "Data Center - Rack 2",
            responsable = "Carlos Ramírez",
            estado = EstadoEquipo.MANTENIMIENTO,
            ultimaActualizacion = "Hoy, 07:45 a.m."
        ),
        Equipo(
            id = "3",
            nombre = "Switch Cisco Catalyst 2960",
            tipo = "Red",
            numeroSerie = "CS-2960-1190",
            ubicacion = "Data Center - Rack 1",
            responsable = "Jorge Salinas",
            estado = EstadoEquipo.OPERATIVO,
            ultimaActualizacion = "Ayer, 06:30 p.m."
        ),
        Equipo(
            id = "4",
            nombre = "Impresora HP LaserJet M404",
            tipo = "Impresora",
            numeroSerie = "HP-M404-0087",
            ubicacion = "Piso 1 - Recepción",
            responsable = "Lucía Torres",
            estado = EstadoEquipo.FUERA_SERVICIO,
            ultimaActualizacion = "Ayer, 03:15 p.m."
        ),
        Equipo(
            id = "5",
            nombre = "Laptop Lenovo ThinkPad X1",
            tipo = "Laptop",
            numeroSerie = "LN-X1C-3352",
            ubicacion = "Piso 2 - Gerencia",
            responsable = "Andrés Vidal",
            estado = EstadoEquipo.ASIGNADO,
            ultimaActualizacion = "Hoy, 09:02 a.m."
        ),
        Equipo(
            id = "6",
            nombre = "Access Point Ubiquiti UAP-AC",
            tipo = "Red",
            numeroSerie = "UB-UAPAC-5567",
            ubicacion = "Piso 3 - Desarrollo",
            responsable = "María Fernández",
            estado = EstadoEquipo.OPERATIVO,
            ultimaActualizacion = "Hace 2 días"
        )
    )

    suspend fun getEquipos(): List<Equipo> {
        delay(600) // Simula latencia de red
        return equipos
    }
}
