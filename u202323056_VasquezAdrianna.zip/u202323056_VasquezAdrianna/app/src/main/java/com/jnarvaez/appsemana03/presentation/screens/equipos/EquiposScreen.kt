package com.jnarvaez.appsemana03.presentation.screens.equipos

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.jnarvaez.appsemana03.di.AppContainer
import com.jnarvaez.appsemana03.domain.model.EstadoEquipo
import com.jnarvaez.appsemana03.presentation.components.EmptyScreen
import com.jnarvaez.appsemana03.presentation.components.LoadingScreen
import com.jnarvaez.appsemana03.ui.theme.CtEstadoFueraServicio
import com.jnarvaez.appsemana03.ui.theme.CtEstadoFueraServicioBg
import com.jnarvaez.appsemana03.ui.theme.CtEstadoMantenimiento
import com.jnarvaez.appsemana03.ui.theme.CtEstadoMantenimientoBg
import com.jnarvaez.appsemana03.ui.theme.CtEstadoOperativo
import com.jnarvaez.appsemana03.ui.theme.CtEstadoOperativoBg
import com.jnarvaez.appsemana03.ui.theme.CtOnSurfaceVariant
import com.jnarvaez.appsemana03.ui.theme.CtOutlineVariant
import com.jnarvaez.appsemana03.ui.theme.CtPrimaryContainer
import com.jnarvaez.appsemana03.ui.theme.CtSurfaceContainer
import com.jnarvaez.appsemana03.ui.theme.CtSurfaceContainerLowest

@Composable
fun EquiposScreen(container: AppContainer) {
    val viewModel = container.equiposViewModel
    val uiState by viewModel.uiState.collectAsState()

    if (uiState.isLoading) {
        LoadingScreen("Cargando equipos...")
        return
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // ---------- Resumen de estados ----------
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            ResumenEstadoCard(
                titulo = "Disponible",
                cantidad = uiState.totalOperativos,
                color = CtEstadoOperativo,
                fondo = CtEstadoOperativoBg,
                modifier = Modifier.weight(1f)
            )
            ResumenEstadoCard(
                titulo = "En reparación",
                cantidad = uiState.totalMantenimiento,
                color = CtEstadoMantenimiento,
                fondo = CtEstadoMantenimientoBg,
                modifier = Modifier.weight(1f)
            )
            ResumenEstadoCard(
                titulo = "De baja",
                cantidad = uiState.totalFueraServicio,
                color = CtEstadoFueraServicio,
                fondo = CtEstadoFueraServicioBg,
                modifier = Modifier.weight(1f)
            )
        }

        // ---------- Buscador ----------
        TextField(
            value = uiState.busqueda,
            onValueChange = viewModel::onBusquedaChange,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            placeholder = { Text("Buscar equipo, serie o ubicación") },
            singleLine = true,
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = CtOnSurfaceVariant) },
            shape = RoundedCornerShape(12.dp),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = CtSurfaceContainer,
                unfocusedContainerColor = CtSurfaceContainer,
                focusedIndicatorColor = CtPrimaryContainer,
                unfocusedIndicatorColor = CtOutlineVariant
            )
        )

        Spacer(modifier = Modifier.height(12.dp))

        // ---------- Filtros por estado ----------
        LazyRow(
            modifier = Modifier.padding(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(EstadoEquipo.entries.toList()) { estado ->
                FilterChip(
                    selected = uiState.filtroEstado == estado,
                    onClick = { viewModel.onFiltroChange(estado) },
                    label = { Text(estado.etiqueta) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = CtPrimaryContainer,
                        selectedLabelColor = androidx.compose.ui.graphics.Color.White
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // ---------- Listado de equipos ----------
        val equipos = uiState.equiposFiltrados
        if (equipos.isEmpty()) {
            EmptyScreen("No hay equipos que coincidan con la búsqueda")
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 16.dp)
            ) {
                items(equipos) { equipo ->
                    EquipoItem(equipo = equipo)
                }
            }
        }
    }
}

@Composable
private fun ResumenEstadoCard(
    titulo: String,
    cantidad: Int,
    color: androidx.compose.ui.graphics.Color,
    fondo: androidx.compose.ui.graphics.Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = fondo)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.Start
        ) {
            Text(
                text = cantidad.toString(),
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = color
            )
            Text(
                text = titulo,
                style = MaterialTheme.typography.labelSmall,
                color = color
            )
        }
    }
}
