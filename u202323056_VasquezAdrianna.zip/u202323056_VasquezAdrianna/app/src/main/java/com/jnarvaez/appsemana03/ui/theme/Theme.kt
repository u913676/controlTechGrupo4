package com.jnarvaez.appsemana03.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = Purple80,
    secondary = PurpleGrey80,
    tertiary = Pink80
)

private val LightColorScheme = lightColorScheme(
    primary = CtPrimaryContainer,
    onPrimary = Color.White,
    primaryContainer = CtPrimaryContainer,
    onPrimaryContainer = CtOnPrimaryContainer,
    secondary = CtSecondaryContainer,
    onSecondary = Color.White,
    secondaryContainer = CtSecondaryContainer,
    onSecondaryContainer = CtOnSecondaryContainer,
    tertiary = CtTertiary,
    onTertiary = Color.White,
    tertiaryContainer = CtTertiaryContainer,
    background = CtBackground,
    onBackground = CtOnBackground,
    surface = CtSurface,
    onSurface = CtOnSurface,
    surfaceVariant = CtSurfaceContainerHighest,
    onSurfaceVariant = CtOnSurfaceVariant,
    outline = CtOutline,
    outlineVariant = CtOutlineVariant,
    error = CtError,
    onError = CtOnError,
    errorContainer = CtErrorContainer,
    onErrorContainer = CtOnErrorContainer
)

@Composable
fun AppSemana03Theme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    // Se desactiva por defecto para conservar la identidad de marca ControlTech
    // (con dynamicColor=true, Android 12+ reemplazaría los colores por los del wallpaper)
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }

        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}