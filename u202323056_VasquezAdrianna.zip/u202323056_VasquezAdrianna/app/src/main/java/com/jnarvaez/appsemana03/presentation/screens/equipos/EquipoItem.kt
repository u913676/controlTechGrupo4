package com.jnarvaez.appsemana03.presentation.screens.equipos

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Laptop
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Place
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.jnarvaez.appsemana03.domain.model.Equipo
import com.jnarvaez.appsemana03.domain.model.EstadoEquipo
import com.jnarvaez.appsemana03.ui.theme.CtEstadoAsignado
import com.jnarvaez.appsemana03.ui.theme.CtEstadoAsignadoBg
import com.jnarvaez.appsemana03.ui.theme.CtEstadoFueraServicio
import com.jnarvaez.appsemana03.ui.theme.CtEstadoFueraServicioBg
import com.jnarvaez.appsemana03.ui.theme.CtEstadoMantenimiento
import com.jnarvaez.appsemana03.ui.theme.CtEstadoMantenimientoBg
import com.jnarvaez.appsemana03.ui.theme.CtEstadoOperativo
import com.jnarvaez.appsemana03.ui.theme.CtEstadoOperativoBg
import com.jnarvaez.appsemana03.ui.theme.CtOnSurfaceVariant
import com.jnarvaez.appsemana03.ui.theme.CtOutlineVariant
import com.jnarvaez.appsemana03.ui.theme.CtSurfaceContainerLowest

private data class EstadoColores(val texto: androidx.compose.ui.graphics.Color, val fondo: androidx.compose.ui.graphics.Color)

private fun coloresDe(estado: EstadoEquipo): EstadoColores = when (estado) {
    EstadoEquipo.OPERATIVO -> EstadoColores(CtEstadoOperativo, CtEstadoOperativoBg)
    EstadoEquipo.MANTENIMIENTO -> EstadoColores(CtEstadoMantenimiento, CtEstadoMantenimientoBg)
    EstadoEquipo.FUERA_SERVICIO -> EstadoColores(CtEstadoFueraServicio, CtEstadoFueraServicioBg)
    EstadoEquipo.ASIGNADO -> EstadoColores(CtEstadoAsignado, CtEstadoAsignadoBg)
}

private fun iconoDe(tipo: String): ImageVector = when {
    tipo.contains("laptop", ignoreCase = true) -> Icons.Default.Laptop
    tipo.contains("servidor", ignoreCase = true) -> Icons.Default.Dns
    tipo.contains("red", ignoreCase = true) -> Icons.Default.Router
    tipo.contains("impresora", ignoreCase = true) -> Icons.Default.Print
    else -> Icons.Default.Devices
}

@Composable
fun EquipoItem(equipo: Equipo, onClick: () -> Unit = {}) {
    val colores = coloresDe(equipo.estado)

    Card(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CtSurfaceContainerLowest),
        border = BorderStroke(1.dp, CtOutlineVariant),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Icon(
                        imageVector = iconoDe(equipo.tipo),
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.width(28.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = equipo.nombre,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = equipo.numeroSerie,
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace,
                            color = CtOnSurfaceVariant
                        )
                    }
                }

                // ---- Chip de estado ----
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(colores.fondo)
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(colores.texto)
                            .height(6.dp)
                            .width(6.dp)
                    ) {}
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = equipo.estado.etiqueta,
                        style = MaterialTheme.typography.labelSmall,
                        color = colores.texto,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Place,
                    contentDescription = null,
                    tint = CtOnSurfaceVariant,
                    modifier = Modifier.width(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = equipo.ubicacion,
                    style = MaterialTheme.typography.bodySmall,
                    color = CtOnSurfaceVariant
                )
                Spacer(modifier = Modifier.width(16.dp))
                Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = null,
                    tint = CtOnSurfaceVariant,
                    modifier = Modifier.width(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = equipo.responsable,
                    style = MaterialTheme.typography.bodySmall,
                    color = CtOnSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Actualizado: ${equipo.ultimaActualizacion}",
                style = MaterialTheme.typography.labelSmall,
                color = CtOutlineVariant
            )
        }
    }
}
