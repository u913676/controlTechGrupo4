package com.jnarvaez.appsemana03.data.mapper

import com.jnarvaez.appsemana03.data.remote.dto.InsertarLibroRequest
import com.jnarvaez.appsemana03.data.remote.dto.LibroDto
import com.jnarvaez.appsemana03.domain.model.Libro

object LibroMapper {
    fun toDomain(libroDto: LibroDto) : Libro =
        Libro(libroDto.id,libroDto.titulo,libroDto.autor,libroDto.anio,libroDto.genero,libroDto.descripcion)

    fun toInsertLibroRequest(libro: Libro) : InsertarLibroRequest =
        InsertarLibroRequest(libro.titulo,libro.autor,libro.anio,libro.genero,libro.descripcion)
}