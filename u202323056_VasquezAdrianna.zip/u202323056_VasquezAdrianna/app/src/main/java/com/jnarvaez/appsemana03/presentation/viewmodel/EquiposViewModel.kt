package com.jnarvaez.appsemana03.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jnarvaez.appsemana03.domain.model.EstadoEquipo
import com.jnarvaez.appsemana03.domain.usecase.GetEquiposUseCase
import com.jnarvaez.appsemana03.presentation.event.EventBus
import com.jnarvaez.appsemana03.presentation.event.UiEvent
import com.jnarvaez.appsemana03.presentation.screens.equipos.EquiposUiState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class EquiposViewModel(private val getEquiposUseCase: GetEquiposUseCase) : ViewModel() {
    private val _uiState = MutableStateFlow(EquiposUiState())
    val uiState = _uiState.asStateFlow()

    init {
        cargarEquipos()
    }

    fun cargarEquipos() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            try {
                val equipos = getEquiposUseCase()
                _uiState.update { it.copy(listaEquipos = equipos, isLoading = false) }
            } catch (e: Exception) {
                _uiState.update { it.copy(isLoading = false, error = e.message) }
                EventBus.send(UiEvent.Error("Error al cargar equipos: ${e.message}"))
            }
        }
    }

    fun onBusquedaChange(value: String) {
        _uiState.update { it.copy(busqueda = value) }
    }

    fun onFiltroChange(estado: EstadoEquipo?) {
        _uiState.update {
            it.copy(filtroEstado = if (it.filtroEstado == estado) null else estado)
        }
    }
}
