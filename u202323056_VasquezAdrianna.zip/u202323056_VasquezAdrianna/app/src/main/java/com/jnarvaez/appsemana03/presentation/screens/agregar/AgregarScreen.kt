package com.jnarvaez.appsemana03.presentation.screens.agregar

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.jnarvaez.appsemana03.di.AppContainer
import com.jnarvaez.appsemana03.presentation.components.FormLibro

@Composable
fun AgregarScreen(container: AppContainer, navHostController: NavHostController){
    val viewModel = container.agregarLibroViewModel
    val uiState by viewModel.uiState.collectAsState()

    LaunchedEffect(uiState.isSuccess) {
        if(uiState.isSuccess){
            container.inicioViewModel.cargarLibros()
            viewModel.clearSuccess()
            navHostController.popBackStack()
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        FormLibro(
            uiState.titulo,uiState.autor,uiState.anio,uiState.genero,uiState.descripcion,
            viewModel::onTituloChange,viewModel::onAutorChange,viewModel::onAnioChange,
            viewModel::onGeneroChange,viewModel::onDescripcionChange
        )
        Spacer(modifier = Modifier.height(16.dp))
        Button(
            modifier = Modifier.fillMaxWidth(),
            onClick = { viewModel.guardarLibro() },
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFFE91E63),
                contentColor = Color(0xFFFFFFFF)
            )
        ) {
            Icon(Icons.Default.Save,"")
            Spacer(modifier = Modifier.width(8.dp))
            Text("Guardar Libro")
        }
    }
}