package com.jnarvaez.appsemana03.data.remote.dto

data class EquiposDataDto(
    val items: List<EquipoDto>,
    val nextKey: String?
)
