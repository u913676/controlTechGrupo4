package com.jnarvaez.appsemana03.data.remote.dto

data class InsertarEquipoRequest(
    val nombre: String,
    val tipo: String,
    val numeroSerie: String,
    val ubicacion: String,
    val responsable: String,
    val estado: String
)
