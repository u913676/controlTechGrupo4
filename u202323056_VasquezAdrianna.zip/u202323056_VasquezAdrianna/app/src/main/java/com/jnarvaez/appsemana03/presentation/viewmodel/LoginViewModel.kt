package com.jnarvaez.appsemana03.presentation.viewmodel

import android.util.Patterns
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jnarvaez.appsemana03.domain.usecase.LoginUseCase
import com.jnarvaez.appsemana03.presentation.event.EventBus
import com.jnarvaez.appsemana03.presentation.event.UiEvent
import com.jnarvaez.appsemana03.presentation.screens.login.LoginUiState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class LoginViewModel(private val loginUseCase: LoginUseCase) : ViewModel() {
    private val _uiState = MutableStateFlow(LoginUiState())
    val uiState = _uiState.asStateFlow()

    fun onCorreoChange(value: String) {
        _uiState.update { it.copy(correo = value, errorCorreo = null) }
    }

    fun onContrasenaChange(value: String) {
        _uiState.update { it.copy(contrasena = value, errorContrasena = null) }
    }

    fun onRecordarmeChange(value: Boolean) {
        _uiState.update { it.copy(recordarme = value) }
    }

    fun toggleMostrarContrasena() {
        _uiState.update { it.copy(mostrarContrasena = !it.mostrarContrasena) }
    }

    fun iniciarSesion() {
        val estado = _uiState.value
        val errorCorreo = when {
            estado.correo.isBlank() -> "Ingresa tu correo electrónico"
            !Patterns.EMAIL_ADDRESS.matcher(estado.correo).matches() -> "Correo electrónico inválido"
            else -> null
        }
        val errorContrasena = when {
            estado.contrasena.isBlank() -> "Ingresa tu contraseña"
            estado.contrasena.length < 6 -> "Debe tener al menos 6 caracteres"
            else -> null
        }

        if (errorCorreo != null || errorContrasena != null) {
            _uiState.update { it.copy(errorCorreo = errorCorreo, errorContrasena = errorContrasena) }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            try {
                val exito = loginUseCase(estado.correo, estado.contrasena)
                if (exito) {
                    _uiState.update { it.copy(isLoading = false, loginExitoso = true) }
                } else {
                    _uiState.update {
                        it.copy(isLoading = false, errorContrasena = "Correo o contraseña incorrectos")
                    }
                    EventBus.send(UiEvent.Error("Credenciales inválidas"))
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(isLoading = false) }
                EventBus.send(UiEvent.Error("Error al iniciar sesión: ${e.message}"))
            }
        }
    }
}
