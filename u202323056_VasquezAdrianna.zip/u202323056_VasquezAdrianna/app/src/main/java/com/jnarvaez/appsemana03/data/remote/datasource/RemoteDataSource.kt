package com.jnarvaez.appsemana03.data.remote.datasource

import com.jnarvaez.appsemana03.core.network.ApiService
import com.jnarvaez.appsemana03.data.remote.dto.ApiResponse
import com.jnarvaez.appsemana03.data.remote.dto.InsertarLibroRequest
import com.jnarvaez.appsemana03.data.remote.dto.LibroDto

class RemoteDataSource(private val api: ApiService) {
    suspend fun getLibros(): ApiResponse?{
        return api.getLibros().body()
    }

    suspend fun insertarLibro(request: InsertarLibroRequest): LibroDto?{
        return api.insertarLibro(request).body()
    }

    suspend fun getLibroById(id: String): LibroDto?{
        return api.getLibroById(id).body()?.data
    }

    suspend fun actualizarLibro(id:String, request: InsertarLibroRequest): LibroDto?{
        return api.actualizarLibro(id,request).body()
    }

    suspend fun eliminarLibro(id: String){
        api.eliminarLibro(id)
    }
}